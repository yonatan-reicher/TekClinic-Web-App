'use client';
import MyApp from './MyApp';
import React from 'react';
import AuthContextProvider from './context/AuthContextProvider';
import { MantineProvider } from '@mantine/core';
import { BrowserRouter, createBrowserRouter } from 'react-router-dom';



function App() {


  return (
    
    <AuthContextProvider>
      <React.StrictMode>
      <MantineProvider>
      <BrowserRouter>
        <MyApp />
        </BrowserRouter>
      </MantineProvider>
      </React.StrictMode>
    </AuthContextProvider>
  )
}

export default App;