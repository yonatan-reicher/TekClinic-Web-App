import React, { useContext } from 'react';
import Home from './pages/Home';
import PatientsPage from './pages/PatientsPage';
import VolunteersDoctorsPage from './pages/VolunteersDoctorsPage';
import AppointmentsPage from './pages/AppointmentsPage'; import { Loader, Center, Container } from '@mantine/core';
import { AuthContext } from './context/AuthContextProvider';
import { BrowserRouter as Router, Link , Route, Routes } from 'react-router-dom';
import { useDisclosure } from '@mantine/hooks';
import {Flex, AppShell, Burger, Button, Paper} from '@mantine/core';
import {FaBars} from 'react-icons/fa';
import './App.css';
import Navbar from './components/Navbar';
import Header from './components/Header';
import RouterSwitcher from './components/RouterSwitcher';
import { useNavigate } from 'react-router-dom';
 

function MyApp() {
  const authContext = useContext(AuthContext);
  const [opened, {toggle}] = useDisclosure();

  return (
    authContext.isAuthenticated ? (
      <div className='App' style={{marginTop: '20px'}}> 
      <AppShell
      header={{ height: 60}}
      navbar={{
        width: 200,
        breakpoint: 'sm',
        collapsed: { mobile: !opened}
      }}
      padding="md"
    >
      <Header toggle={toggle} opened={opened} />

      <Navbar />
      <AppShell.Main>
        <RouterSwitcher />
      </AppShell.Main>

      <AppShell.Footer>
        <div style={{ color: '#888', fontSize: '17px'}}> built by team 8 </div>
      </AppShell.Footer>
      </AppShell>
    </div>
    ) : (
      <Center style={{ height: '100vh' }}>
        <Loader />
      </Center>
    )
  );
}
export default MyApp;